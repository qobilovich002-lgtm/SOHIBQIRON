// PerformanceMonitor.cs
// Joylashuv: Assets/Game/Tools/
// FPS, frame time, memory — faqat development buildda ko'rinadi

using UnityEngine;

namespace Sohibqiron.Tools
{
    public class PerformanceMonitor : MonoBehaviour
    {
        [Header("Ko'rsatish sozlamalari")]
        [SerializeField] private bool showInRelease = false;
        [SerializeField] private KeyCode toggleKey = KeyCode.F1;

        private bool  _visible = true;
        private float _fps;
        private float _frameTime;
        private float _fpsTimer;
        private int   _frameCount;
        private long  _memoryMB;
        private const float UpdateInterval = 0.5f;

        // GUI uslub
        private GUIStyle _style;
        private GUIStyle _badStyle;

        private void Start()
        {
#if !UNITY_EDITOR && !DEVELOPMENT_BUILD
            if (!showInRelease) { gameObject.SetActive(false); return; }
#endif
            _style = new GUIStyle
            {
                fontSize = 20,
                fontStyle = FontStyle.Bold,
                normal = { textColor = Color.white }
            };
            _badStyle = new GUIStyle(_style) { normal = { textColor = new Color(1f,0.3f,0.2f) } };
        }

        private void Update()
        {
            if (UnityEngine.Input.GetKeyDown(toggleKey)) _visible = !_visible;

            _fpsTimer  += Time.unscaledDeltaTime;
            _frameCount++;
            if (_fpsTimer >= UpdateInterval)
            {
                _fps       = _frameCount / _fpsTimer;
                _frameTime = _fpsTimer / _frameCount * 1000f;
                _fpsTimer  = 0f;
                _frameCount= 0;
                _memoryMB  = System.GC.GetTotalMemory(false) / 1024 / 1024;
            }
        }

        private void OnGUI()
        {
            if (!_visible) return;

            float x = 12f, y = 12f, lineH = 26f;

            // FPS
            bool fpsOk = _fps >= 28f;
            GUI.Label(new Rect(x, y, 250, 30), $"FPS: {_fps:F0}", fpsOk ? _style : _badStyle);
            y += lineH;

            // Frame time
            GUI.Label(new Rect(x, y, 250, 30), $"Frame: {_frameTime:F1} ms", _style);
            y += lineH;

            // RAM
            bool memOk = _memoryMB < 800;
            GUI.Label(new Rect(x, y, 250, 30), $"RAM: {_memoryMB} MB", memOk ? _style : _badStyle);
            y += lineH;

            // Platform
            GUI.Label(new Rect(x, y, 300, 30), $"Platform: {Application.platform}", _style);
            y += lineH;

            // Grafika sifati
            var gs = Settings.GraphicsSettingsManager.Instance;
            if (gs != null)
                GUI.Label(new Rect(x, y, 300, 30), $"Grafika: {gs.CurrentSettings.Quality}", _style);
        }
    }
}
