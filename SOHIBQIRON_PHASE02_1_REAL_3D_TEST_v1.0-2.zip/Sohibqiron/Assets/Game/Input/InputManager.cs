// InputManager.cs
// Joylashuv: Assets/Game/Input/
// Android touch va PC keyboard/mouse — birlashtirilgan input tizimi

using UnityEngine;
using UnityEngine.EventSystems;

namespace Sohibqiron.InputSystem
{
    public class InputManager : MonoBehaviour
    {
        public static InputManager Instance { get; private set; }

        [Header("Joystick sozlamalari")]
        [SerializeField] private float joystickDeadzone = 0.15f;
        [SerializeField] private float joystickRadius = 55f;

        [Header("Kamera sezgirligi")]
        [SerializeField] private float touchLookSensitivity = 0.3f;
        [SerializeField] private float mouseLookSensitivity = 2.5f;

        // Chiqish qiymatlari (readonly)
        public Vector2 MoveInput   { get; private set; }
        public Vector2 LookInput   { get; private set; }
        public bool    JumpPressed  { get; private set; }
        public bool    DodgePressed { get; private set; }
        public bool    AttackPressed{ get; private set; }
        public bool    BowPressed   { get; private set; }
        public bool    SprintHeld   { get; private set; }
        public bool    InteractPressed { get; private set; }

        // Touch ID'lar
        private int _moveTouchId   = -1;
        private int _lookTouchId   = -1;
        private Vector2 _moveOrigin;
        private Vector2 _lookLastPos;

        // Keyboard holati
        private bool _jumpConsumed;
        private bool _dodgeConsumed;
        private bool _attackConsumed;

        private void Awake()
        {
            if (Instance != null && Instance != this) { Destroy(gameObject); return; }
            Instance = this;
        }

        private void Update()
        {
            // Har kadrda reset
            JumpPressed = false;
            DodgePressed = false;
            AttackPressed = false;
            InteractPressed = false;
            LookInput = Vector2.zero;

            if (Application.isMobilePlatform || SystemInfo.deviceType == DeviceType.Handheld)
                HandleTouchInput();
            else
                HandleKeyboardInput();
        }

        // ─── TOUCH ───────────────────────────────────────────
        private void HandleTouchInput()
        {
            foreach (Touch touch in UnityEngine.Input.touches)
            {
                // UI tugmasi bosimini o'tkazib yuboring
                if (EventSystem.current != null && EventSystem.current.IsPointerOverGameObject(touch.fingerId))
                    continue;

                float screenHalfW = Screen.width * 0.5f;

                switch (touch.phase)
                {
                    case TouchPhase.Began:
                        if (touch.position.x < screenHalfW && _moveTouchId == -1)
                        {
                            _moveTouchId = touch.fingerId;
                            _moveOrigin = touch.position;
                        }
                        else if (touch.position.x >= screenHalfW && _lookTouchId == -1)
                        {
                            _lookTouchId = touch.fingerId;
                            _lookLastPos = touch.position;
                        }
                        break;

                    case TouchPhase.Moved:
                        if (touch.fingerId == _moveTouchId)
                        {
                            Vector2 delta = touch.position - _moveOrigin;
                            MoveInput = Vector2.ClampMagnitude(delta / joystickRadius, 1f);
                            if (MoveInput.magnitude < joystickDeadzone) MoveInput = Vector2.zero;
                        }
                        else if (touch.fingerId == _lookTouchId)
                        {
                            Vector2 delta = touch.position - _lookLastPos;
                            LookInput = delta * touchLookSensitivity;
                            _lookLastPos = touch.position;
                        }
                        break;

                    case TouchPhase.Ended:
                    case TouchPhase.Canceled:
                        if (touch.fingerId == _moveTouchId) { _moveTouchId = -1; MoveInput = Vector2.zero; }
                        if (touch.fingerId == _lookTouchId) { _lookTouchId = -1; }
                        break;
                }
            }
        }

        // ─── KEYBOARD ────────────────────────────────────────
        private void HandleKeyboardInput()
        {
            float h = UnityEngine.Input.GetAxisRaw("Horizontal");
            float v = UnityEngine.Input.GetAxisRaw("Vertical");
            MoveInput = new Vector2(h, v);

            float mx = UnityEngine.Input.GetAxis("Mouse X") * mouseLookSensitivity;
            float my = UnityEngine.Input.GetAxis("Mouse Y") * mouseLookSensitivity;
            LookInput = new Vector2(mx, my);

            SprintHeld    = UnityEngine.Input.GetKey(KeyCode.LeftShift);
            JumpPressed   = UnityEngine.Input.GetKeyDown(KeyCode.Space);
            DodgePressed  = UnityEngine.Input.GetKeyDown(KeyCode.LeftControl);
            AttackPressed = UnityEngine.Input.GetMouseButtonDown(0);
            BowPressed    = UnityEngine.Input.GetMouseButtonDown(1);
            InteractPressed = UnityEngine.Input.GetKeyDown(KeyCode.E);

            // Cursor qulfash (Editor'da RMB ushlab turing)
            if (UnityEngine.Input.GetMouseButtonDown(1))
                Cursor.lockState = CursorLockMode.Locked;
            if (UnityEngine.Input.GetKeyDown(KeyCode.Escape))
                Cursor.lockState = CursorLockMode.None;
        }

        // HUD tugmalaridan chaqiriladi
        public void OnJumpButton()    => JumpPressed = true;
        public void OnDodgeButton()   => DodgePressed = true;
        public void OnAttackButton()  => AttackPressed = true;
        public void OnBowButton()     => BowPressed = true;
        public void OnSprintDown()    => SprintHeld = true;
        public void OnSprintUp()      => SprintHeld = false;
        public void OnInteractButton()=> InteractPressed = true;
    }
}
