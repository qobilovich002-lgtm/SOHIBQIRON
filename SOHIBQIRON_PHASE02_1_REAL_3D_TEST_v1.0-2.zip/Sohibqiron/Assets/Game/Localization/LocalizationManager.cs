// LocalizationManager.cs
// Joylashuv: Assets/Game/Localization/
// Ko'p tilli matn tizimi — Uzbek (asosiy), Russian, English

using UnityEngine;
using System.Collections.Generic;
using System.IO;

namespace Sohibqiron.Localization
{
    public class LocalizationManager : MonoBehaviour
    {
        public static LocalizationManager Instance { get; private set; }

        [SerializeField] private Language defaultLanguage = Language.Uzbek;

        public Language CurrentLanguage { get; private set; }
        private Dictionary<string, string> _strings = new();

        public static event System.Action OnLanguageChanged;

        private void Awake()
        {
            if (Instance != null && Instance != this) { Destroy(gameObject); return; }
            Instance = this;
            DontDestroyOnLoad(gameObject);

            string saved = PlayerPrefs.GetString("Language", defaultLanguage.ToString());
            CurrentLanguage = System.Enum.TryParse<Language>(saved, out var lang) ? lang : defaultLanguage;
            LoadLanguage(CurrentLanguage);
        }

        public void SetLanguage(Language lang)
        {
            CurrentLanguage = lang;
            PlayerPrefs.SetString("Language", lang.ToString());
            LoadLanguage(lang);
            OnLanguageChanged?.Invoke();
        }

        private void LoadLanguage(Language lang)
        {
            _strings.Clear();
            string filename = lang switch
            {
                Language.Uzbek   => "uz",
                Language.Russian => "ru",
                Language.English => "en",
                _                => "uz"
            };

            // StreamingAssets'dan o'qish
            string path = Path.Combine(Application.streamingAssetsPath, "Localization", $"{filename}.json");

            if (File.Exists(path))
            {
                string json = File.ReadAllText(path);
                var data = JsonUtility.FromJson<LocalizationFile>(json);
                foreach (var entry in data.entries)
                    _strings[entry.key] = entry.value;
                Debug.Log($"[Localization] {lang} tili yuklandi. {_strings.Count} ta matn.");
            }
            else
            {
                Debug.LogWarning($"[Localization] {path} topilmadi. Standart matnlar ishlatiladi.");
                LoadFallback();
            }
        }

        private void LoadFallback()
        {
            // Minimal o'zbek matni — fayllar bo'lmasa ham ishlaydi
            _strings = new Dictionary<string, string>
            {
                {"ui.hp",            "Qon"},
                {"ui.stamina",       "Kuch"},
                {"ui.ammo",          "O'qlar"},
                {"ui.mission",       "Vazifa"},
                {"ui.pause",         "Pauza"},
                {"ui.resume",        "Davom etish"},
                {"ui.settings",      "Sozlamalar"},
                {"ui.quit",          "Chiqish"},
                {"mission.main",     "Asosiy vazifa"},
                {"mission.optional", "Qo'shimcha vazifa"},
                {"chapter.01",       "Movarounnahr va Samarqand"},
                {"city.samarkand",   "Samarqand"},
                {"msg.enemy_near",   "Dushman yaqinlashmoqda!"},
                {"msg.level_complete","Level tugadi!"},
                {"msg.game_over",    "O'yin tugadi"},
                {"msg.checkpoint",   "Checkpoint saqlandi"},
                {"settings.graphics","Grafika"},
                {"settings.audio",   "Ovoz"},
                {"settings.controls","Boshqaruv"},
                {"graphics.low",     "Past"},
                {"graphics.medium",  "O'rta"},
                {"graphics.high",    "Yuqori"},
                {"graphics.ultra",   "Ultra"},
            };
        }

        public string Get(string key)
        {
            return _strings.TryGetValue(key, out string val) ? val : $"[{key}]";
        }

        public string Get(string key, params object[] args)
        {
            string text = Get(key);
            try { return string.Format(text, args); }
            catch { return text; }
        }
    }

    public enum Language { Uzbek, Russian, English }

    [System.Serializable]
    public class LocalizationEntry { public string key; public string value; }

    [System.Serializable]
    public class LocalizationFile { public LocalizationEntry[] entries; }
}
