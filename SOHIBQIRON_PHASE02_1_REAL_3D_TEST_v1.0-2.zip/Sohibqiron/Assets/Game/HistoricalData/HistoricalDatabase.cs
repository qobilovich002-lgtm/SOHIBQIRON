// HistoricalDatabase.cs
// Joylashuv: Assets/Game/HistoricalData/
// Tarixiy ma'lumotlar bazasi — fakt va gameplay ajratilgan

using UnityEngine;
using System.Collections.Generic;

namespace Sohibqiron.HistoricalData
{
    [CreateAssetMenu(fileName = "HistoricalDatabase", menuName = "Sohibqiron/Historical Database")]
    public class HistoricalDatabase : ScriptableObject
    {
        [SerializeField] private List<HistoricalEntry> entries = new();

        private Dictionary<string, HistoricalEntry> _index;

        public void Initialize()
        {
            _index = new();
            foreach (var e in entries)
                if (!string.IsNullOrEmpty(e.Id))
                    _index[e.Id] = e;
        }

        public HistoricalEntry Get(string id)
        {
            if (_index == null) Initialize();
            return _index.TryGetValue(id, out var e) ? e : null;
        }

        public List<HistoricalEntry> GetByType(EntryType type)
        {
            return entries.FindAll(e => e.Type == type);
        }
    }

    [System.Serializable]
    public class HistoricalEntry
    {
        [Header("Identifikator")]
        public string Id;
        public EntryType Type;

        [Header("Asosiy ma'lumot")]
        public string NameUz;
        public string NameRu;
        public string NameEn;
        public string Year;           // "1370" yoki "1370-1380"
        public string Location;

        [Header("Tavsif")]
        [TextArea(3, 8)] public string DescriptionUz;
        [TextArea(3, 8)] public string DescriptionRu;
        [TextArea(3, 8)] public string DescriptionEn;

        [Header("Manba")]
        public string Source;         // Ibn Arabshoh, Yazdi va h.k.
        public bool   IsUncertain;    // Tarixiy manbalarda kelishmovchilik
        [TextArea(2, 4)] public string UncertaintyNote;

        [Header("Gameplay bilan bog'liq")]
        public bool   IsInCampaign;   // Bu entry qaysi chapterdami
        public string ChapterId;
    }

    public enum EntryType
    {
        Person,      // Shaxs: Amir Temur, Boyazid, To'xtamish
        Location,    // Joy: Samarqand, Dehli, Anqara
        Battle,      // Jang: Anqara jangi 1402
        Campaign,    // Yurish: Hindiston yurishi 1398
        Event,       // Voqea: Samarqandni poytaxt qilish
        Dynasty,     // Sulola: Temuriylar
        Structure    // Inshoot: Ko'ksaroy, Bibixonim
    }
}
