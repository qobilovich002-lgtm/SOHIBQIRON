// Phase02CameraController.cs
// SOHIBQIRON - PHASE 02.1
// Third-Person Camera — player follow, rotation, zoom, collision
//
// FIX LOG (Phase02.1 Fix):
//   VERIFIED: SetTarget(Transform) public API — used by SceneBuilder
//   VERIFIED: null-safety on target
//   VERIFIED: collision uses Physics.SphereCast from pivot outward
//
// FIX LOG (Camera Fix Pass):
//   FIXED (1): touchBridge field was never assigned from SceneBuilder.
//              Added SetTouchBridge(Phase02TouchInputBridge) public API.
//              SceneBuilder now calls this after creating the bridge.
//   FIXED (2): collisionMask = ~0 caused SphereCast to hit the Player
//              capsule itself, pushing the camera closer than intended.
//              Fix: at Start(), read the target's layer and exclude it
//              from the effective collision mask at runtime.
//              The Inspector field is kept for environment-layer override;
//              player-layer exclusion is applied on top regardless.

using UnityEngine;

namespace Sohibqiron.Phase02
{
    public class Phase02CameraController : MonoBehaviour
    {
        // ----------------------------------------------------------------
        // INSPECTOR
        // ----------------------------------------------------------------
        [Header("=== TARGET ===")]
        [SerializeField] private Transform target;
        [SerializeField] private Vector3   targetOffset = new Vector3(0f, 1.4f, 0f);

        [Header("=== DISTANCE ===")]
        [SerializeField] private float defaultDistance = 5f;
        [SerializeField] private float minDistance     = 2f;
        [SerializeField] private float maxDistance     = 12f;

        [Header("=== PITCH ===")]
        [SerializeField] private float defaultPitch = 20f;
        [SerializeField] private float minPitch     = -15f;
        [SerializeField] private float maxPitch     = 60f;

        [Header("=== SENSITIVITY ===")]
        [SerializeField] private float mouseSensitivity = 3f;
        [SerializeField] private float zoomSensitivity  = 2f;
        [SerializeField] private float smoothSpeed       = 8f;

        [Header("=== COLLISION ===")]
        // Inspector value is used as the base mask.
        // At Start() the player's own layer is excluded from the effective mask.
        [SerializeField] private LayerMask collisionMask   = ~0;
        [SerializeField] private float     collisionRadius = 0.3f;

        // ----------------------------------------------------------------
        // ANDROID TOUCH — assigned by SceneBuilder via SetTouchBridge()
        // ----------------------------------------------------------------
        [SerializeField] private Phase02TouchInputBridge touchBridge;

        // ----------------------------------------------------------------
        // PRIVATE STATE
        // ----------------------------------------------------------------
        private float     _yaw;
        private float     _pitch;
        private float     _currentDistance;
        private LayerMask _effectiveCollisionMask; // collisionMask minus player layer

        // ----------------------------------------------------------------
        // PUBLIC API — both called by Phase02SceneBuilder
        // ----------------------------------------------------------------

        /// <summary>Assign the player transform as camera target.</summary>
        public void SetTarget(Transform t)
        {
            target = t;
        }

        /// <summary>Assign the scene's single TouchInputBridge instance.
        /// Called by Phase02SceneBuilder after creating the bridge.</summary>
        public void SetTouchBridge(Phase02TouchInputBridge bridge)
        {
            touchBridge = bridge;
        }

        // ----------------------------------------------------------------
        private void Start()
        {
            _yaw             = transform.eulerAngles.y;
            _pitch           = defaultPitch;
            _currentDistance = defaultDistance;

            // --- Compute effective collision mask (exclude player layer) ---
            // Start from the Inspector-configured base mask.
            _effectiveCollisionMask = collisionMask;

            if (target != null)
            {
                // Remove the target's layer so SphereCast never hits the player.
                int playerLayer = target.gameObject.layer;
                _effectiveCollisionMask &= ~(1 << playerLayer);
                Debug.Log($"[Phase02Camera] Collision mask excludes layer {playerLayer} " +
                          $"(\"{LayerMask.LayerToName(playerLayer)}\") to prevent self-hit.");
            }
            else
            {
                Debug.LogWarning("[Phase02Camera] No target assigned. " +
                                 "Call SetTarget() or assign via Inspector.");
            }

            if (touchBridge == null)
                Debug.LogWarning("[Phase02Camera] touchBridge not assigned. " +
                                 "Call SetTouchBridge() or assign via Inspector.");
        }

        // ----------------------------------------------------------------
        // LateUpdate — runs after player movement each frame
        // ----------------------------------------------------------------
        private void LateUpdate()
        {
            if (target == null) return;

            ReadInput();
            ApplyCamera();
        }

        // ----------------------------------------------------------------
        private void ReadInput()
        {
            bool usingTouch = touchBridge != null && touchBridge.UseTouchInput;

            if (usingTouch)
            {
                _yaw             += touchBridge.TouchDelta.x * mouseSensitivity * 0.5f;
                _pitch           -= touchBridge.TouchDelta.y * mouseSensitivity * 0.5f;
                _currentDistance  = Mathf.Clamp(
                    _currentDistance - touchBridge.TouchZoom,
                    minDistance, maxDistance);
            }
            else
            {
                // PC: right-mouse-button drag rotates; scroll wheel zooms
                if (Input.GetMouseButton(1))
                {
                    _yaw   += Input.GetAxis("Mouse X") * mouseSensitivity;
                    _pitch -= Input.GetAxis("Mouse Y") * mouseSensitivity;
                }

                float scroll = Input.GetAxis("Mouse ScrollWheel");
                _currentDistance = Mathf.Clamp(
                    _currentDistance - scroll * zoomSensitivity * 10f,
                    minDistance, maxDistance);
            }

            _pitch = Mathf.Clamp(_pitch, minPitch, maxPitch);
        }

        // ----------------------------------------------------------------
        private void ApplyCamera()
        {
            Quaternion rotation = Quaternion.Euler(_pitch, _yaw, 0f);
            Vector3 pivot       = target.position + targetOffset;
            Vector3 direction   = rotation * Vector3.back; // unit vector away from pivot

            // SphereCast from pivot outward; uses _effectiveCollisionMask
            // which already excludes the player's own layer.
            float actualDist = _currentDistance;
            if (Physics.SphereCast(pivot, collisionRadius, direction,
                                   out RaycastHit hit, _currentDistance,
                                   _effectiveCollisionMask,
                                   QueryTriggerInteraction.Ignore))
            {
                actualDist = Mathf.Max(hit.distance - collisionRadius, minDistance);
            }

            Vector3 desiredPos = pivot + direction * actualDist;

            transform.position = Vector3.Lerp(transform.position, desiredPos,
                                              smoothSpeed * Time.deltaTime);
            transform.LookAt(pivot);
        }
    }
}
