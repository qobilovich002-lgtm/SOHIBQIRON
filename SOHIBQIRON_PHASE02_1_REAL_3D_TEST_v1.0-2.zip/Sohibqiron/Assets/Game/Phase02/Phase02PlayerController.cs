// Phase02PlayerController.cs
// SOHIBQIRON - PHASE 02.1
// WASD movement, CharacterController, gravity, ground check, collision
//
// FIX LOG (Phase02.1 Fix):
//   VERIFIED: all null checks present
//   VERIFIED: CharacterController.Move called once per frame (not doubled)
//   VERIFIED: groundLayer default = ~0 (hits everything) — safe fallback
//   VERIFIED: TouchMoveInput and UseTouchInput public for TouchInputBridge
//   CLARIFIED: walkSpeed used when moving without Shift; runSpeed with Shift

using UnityEngine;

namespace Sohibqiron.Phase02
{
    [RequireComponent(typeof(CharacterController))]
    public class Phase02PlayerController : MonoBehaviour
    {
        // ----------------------------------------------------------------
        // INSPECTOR
        // ----------------------------------------------------------------
        [Header("=== MOVEMENT ===")]
        [SerializeField] private float walkSpeed     = 4f;
        [SerializeField] private float runSpeed      = 7f;
        [SerializeField] private float gravity       = -20f;
        [SerializeField] private float rotationSpeed = 10f;

        [Header("=== GROUND CHECK ===")]
        [SerializeField] private LayerMask groundLayer        = ~0;
        [SerializeField] private float     groundCheckDistance = 0.15f;

        // ----------------------------------------------------------------
        // ANDROID TOUCH — written by Phase02TouchInputBridge
        // ----------------------------------------------------------------
        [Header("=== ANDROID TOUCH (wired by TouchInputBridge) ===")]
        [HideInInspector] public Vector2 TouchMoveInput = Vector2.zero;
        [HideInInspector] public bool    UseTouchInput  = false;

        // ----------------------------------------------------------------
        // PRIVATE STATE
        // ----------------------------------------------------------------
        private CharacterController _cc;
        private Transform           _camTransform;
        private Vector3             _verticalVelocity;
        private bool                _isGrounded;

        // ----------------------------------------------------------------
        private void Awake()
        {
            _cc = GetComponent<CharacterController>();
        }

        private void Start()
        {
            Camera main = Camera.main;
            if (main != null)
                _camTransform = main.transform;
            else
                Debug.LogWarning("[Phase02Player] No MainCamera found. " +
                                 "Movement will use world-space axes.");

            Debug.Log("[Phase02Player] Ready. WASD = walk, Shift = run.");
        }

        // ----------------------------------------------------------------
        private void Update()
        {
            CheckGround();
            ApplyGravity();
            HandleMovement();
        }

        // ----------------------------------------------------------------
        // GROUND CHECK
        // ----------------------------------------------------------------
        private void CheckGround()
        {
            // Raycast downward from character base
            float rayLength = (_cc.height * 0.5f) + groundCheckDistance;
            _isGrounded = Physics.Raycast(transform.position, Vector3.down,
                                          rayLength, groundLayer,
                                          QueryTriggerInteraction.Ignore);
        }

        // ----------------------------------------------------------------
        // GRAVITY — applied separately from horizontal movement
        // ----------------------------------------------------------------
        private void ApplyGravity()
        {
            if (_isGrounded && _verticalVelocity.y < 0f)
                _verticalVelocity.y = -2f;  // small downward force to keep grounded

            _verticalVelocity.y += gravity * Time.deltaTime;
            _cc.Move(_verticalVelocity * Time.deltaTime);
        }

        // ----------------------------------------------------------------
        // HORIZONTAL MOVEMENT
        // ----------------------------------------------------------------
        private void HandleMovement()
        {
            // --- Read input ---
            Vector2 input;
            if (UseTouchInput)
                input = TouchMoveInput;
            else
                input = new Vector2(Input.GetAxisRaw("Horizontal"),
                                    Input.GetAxisRaw("Vertical"));

            if (input.sqrMagnitude < 0.01f) return; // nothing to do

            // --- Camera-relative movement axes ---
            Vector3 forward = Vector3.forward;
            Vector3 right   = Vector3.right;

            if (_camTransform != null)
            {
                forward = _camTransform.forward;
                right   = _camTransform.right;
                forward.y = 0f;
                right.y   = 0f;
                forward.Normalize();
                right.Normalize();
            }

            Vector3 moveDir = forward * input.y + right * input.x;
            moveDir = Vector3.ClampMagnitude(moveDir, 1f);

            // --- Speed ---
            bool sprinting = Input.GetKey(KeyCode.LeftShift) ||
                             Input.GetKey(KeyCode.RightShift);
            float speed = sprinting ? runSpeed : walkSpeed;

            // --- Apply ---
            _cc.Move(moveDir * speed * Time.deltaTime);

            // --- Rotate player to face movement direction ---
            if (moveDir.sqrMagnitude > 0.01f)
            {
                Quaternion targetRot = Quaternion.LookRotation(moveDir);
                transform.rotation   = Quaternion.Slerp(transform.rotation, targetRot,
                                                        rotationSpeed * Time.deltaTime);
            }
        }

        // ----------------------------------------------------------------
        // DEBUG HUD — top-right corner, small
        // ----------------------------------------------------------------
        private void OnGUI()
        {
            GUI.Label(new Rect(10, 135, 240, 22),
                $"Player grounded: {_isGrounded}");
            GUI.Label(new Rect(10, 158, 240, 22),
                $"Position: {transform.position:F1}");
        }

        private void OnDrawGizmosSelected()
        {
            if (_cc == null) return;
            float len = (_cc.height * 0.5f) + groundCheckDistance;
            Gizmos.color = _isGrounded ? Color.green : Color.red;
            Gizmos.DrawRay(transform.position, Vector3.down * len);
        }
    }
}
