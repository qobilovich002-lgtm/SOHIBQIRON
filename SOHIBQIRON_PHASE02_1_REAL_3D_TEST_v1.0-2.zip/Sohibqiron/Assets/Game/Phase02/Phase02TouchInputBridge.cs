// Phase02TouchInputBridge.cs
// SOHIBQIRON - PHASE 02.1
//
// WHAT THIS IS:
//   Touch input ARCHITECTURE BRIDGE — wires Android touch events to
//   Phase02PlayerController and Phase02CameraController.
//
// WHAT THIS IS NOT:
//   A complete mobile control UI. There is no on-screen virtual joystick
//   widget yet. That is a future task (Phase 03+).
//
// On Android the bridge enables touch routing.
// On PC / Editor it stays disabled; keyboard is used instead.
//
// FIX LOG (Phase02.1 Fix):
//   CLARIFIED: architecture vs complete UI distinction (per spec item 6)
//   VERIFIED: [SerializeField] on playerController and cameraController
//             so SceneBuilder can assign via SerializedObject

using UnityEngine;

namespace Sohibqiron.Phase02
{
    public class Phase02TouchInputBridge : MonoBehaviour
    {
        // ----------------------------------------------------------------
        // REFERENCES — assigned by Phase02SceneBuilder via SerializedObject
        // ----------------------------------------------------------------
        [SerializeField] private Phase02PlayerController playerController;
        [SerializeField] private Phase02CameraController cameraController;

        [Header("Camera touch sensitivity")]
        [SerializeField] private float touchCameraSensitivity = 0.3f;

        // ----------------------------------------------------------------
        // PUBLIC STATE — read by Phase02CameraController each frame
        // ----------------------------------------------------------------
        /// <summary>Normalised movement direction from virtual joystick.
        /// Set by the joystick UI when it exists.
        /// Currently always Vector2.zero (no joystick UI implemented yet).</summary>
        [HideInInspector] public Vector2 JoystickOutput = Vector2.zero;

        /// <summary>Camera delta from second-finger swipe (Android).</summary>
        [HideInInspector] public Vector2 TouchDelta  = Vector2.zero;

        /// <summary>Zoom delta from pinch gesture (not yet implemented).</summary>
        [HideInInspector] public float   TouchZoom   = 0f;

        /// <summary>True when touch routing is active (Android builds only).</summary>
        public bool UseTouchInput { get; private set; }

        // ----------------------------------------------------------------
        private Vector2 _lastCamTouchPos;
        private bool    _trackingCamTouch;

        // ----------------------------------------------------------------
        private void Awake()
        {
#if UNITY_ANDROID && !UNITY_EDITOR
            EnableTouch(true);
            Debug.Log("[TouchBridge] Android detected — touch routing enabled.");
            Debug.Log("[TouchBridge] NOTE: Virtual joystick UI not yet implemented.");
#else
            EnableTouch(false);
            Debug.Log("[TouchBridge] PC/Editor — keyboard active, touch routing off.");
#endif
        }

        private void EnableTouch(bool state)
        {
            UseTouchInput = state;
            if (playerController != null) playerController.UseTouchInput = state;
        }

        // ----------------------------------------------------------------
        private void Update()
        {
#if UNITY_ANDROID && !UNITY_EDITOR
            RoutePlayerInput();
            RouteCameraInput();
#endif
        }

        // ----------------------------------------------------------------
        private void RoutePlayerInput()
        {
            // Virtual joystick widget will write to JoystickOutput when added.
            // For now this passes zero — player will not move via touch.
            if (playerController != null)
                playerController.TouchMoveInput = JoystickOutput;
        }

        // ----------------------------------------------------------------
        private void RouteCameraInput()
        {
            if (Input.touchCount < 2)
            {
                TouchDelta         = Vector2.zero;
                _trackingCamTouch  = false;
                return;
            }

            Touch t = Input.GetTouch(1); // second finger controls camera

            switch (t.phase)
            {
                case TouchPhase.Began:
                    _lastCamTouchPos  = t.position;
                    _trackingCamTouch = true;
                    break;

                case TouchPhase.Moved when _trackingCamTouch:
                    TouchDelta        = (t.position - _lastCamTouchPos) * touchCameraSensitivity;
                    _lastCamTouchPos  = t.position;
                    break;

                case TouchPhase.Ended:
                case TouchPhase.Canceled:
                    TouchDelta        = Vector2.zero;
                    _trackingCamTouch = false;
                    break;

                default:
                    TouchDelta = Vector2.zero;
                    break;
            }
        }

        // ----------------------------------------------------------------
        // PUBLIC API — call from virtual joystick widget (Phase 03+)
        // ----------------------------------------------------------------

        /// <summary>Called by virtual joystick UI each frame it is held.</summary>
        public void OnJoystickInput(Vector2 input)  => JoystickOutput = input;

        /// <summary>Called when joystick is released.</summary>
        public void OnJoystickRelease()             => JoystickOutput = Vector2.zero;
    }
}
