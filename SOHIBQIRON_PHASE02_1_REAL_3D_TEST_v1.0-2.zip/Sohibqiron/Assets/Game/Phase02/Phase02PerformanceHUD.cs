// Phase02PerformanceHUD.cs
// SOHIBQIRON - PHASE 02.1
// Real-time FPS monitor — Android safe
//
// FIX LOG (Phase02.1 Fix):
//   REMOVED: UnityEngine.Rendering.RendererExtensions.GetGPULightmapDataForMesh()
//            — invalid API usage, not a draw-call counter
//   REMOVED: draw call display (not reliably available without Profiler API)
//   KEPT:    FPS, min/max/avg FPS, GC memory, target FPS info

using UnityEngine;

namespace Sohibqiron.Phase02
{
    public class Phase02PerformanceHUD : MonoBehaviour
    {
        [Header("=== TARGET FPS ===")]
        [SerializeField] private int  targetFPS = 60;
        [SerializeField] private bool showHUD   = true;

        // --- FPS tracking ---
        private float _fps;
        private float _avgFPS;
        private float _minFPS    = float.MaxValue;
        private float _maxFPS    = 0f;
        private float _timer;
        private int   _frames;
        private float _totalTime;
        private int   _totalFrames;

        // --- GUI ---
        private GUIStyle _style;
        private bool     _styleReady;

        // ----------------------------------------------------------------
        private void Awake()
        {
            QualitySettings.vSyncCount = 0;

#if UNITY_ANDROID && !UNITY_EDITOR
            Application.targetFrameRate = 30;
            Debug.Log("[PerformanceHUD] Android: 30 FPS target set.");
#else
            Application.targetFrameRate = targetFPS;
            Debug.Log($"[PerformanceHUD] Target FPS: {targetFPS}");
#endif
        }

        // ----------------------------------------------------------------
        private void Update()
        {
            _frames++;
            _timer       += Time.unscaledDeltaTime;
            _totalFrames++;
            _totalTime   += Time.unscaledDeltaTime;

            if (_timer >= 0.5f)
            {
                _fps    = _frames / _timer;
                _frames = 0;
                _timer  = 0f;

                if (_fps < _minFPS) _minFPS = _fps;
                if (_fps > _maxFPS) _maxFPS = _fps;
            }

            if (_totalTime > 0f)
                _avgFPS = _totalFrames / _totalTime;
        }

        // ----------------------------------------------------------------
        private void OnGUI()
        {
            if (!showHUD) return;

            if (!_styleReady)
            {
                _style           = new GUIStyle(GUI.skin.label);
                _style.fontSize  = 14;
                _style.fontStyle = FontStyle.Bold;
                _styleReady      = true;
            }

            float y = 10f;
            const float lineH = 24f;

            // FPS — colour coded
            Color fpsColor = _fps >= 50f ? Color.green
                           : _fps >= 30f ? Color.yellow
                           : Color.red;
            GUI.color = fpsColor;
            GUI.Label(new Rect(10, y, 260, lineH),
                $"FPS: {_fps:F0}  (min: {_minFPS:F0}  max: {_maxFPS:F0})", _style);
            y += lineH;

            GUI.color = Color.white;
            GUI.Label(new Rect(10, y, 200, lineH), $"Avg FPS: {_avgFPS:F1}", _style);
            y += lineH;

            // Managed memory via GC — safe on all platforms
            float memMB = System.GC.GetTotalMemory(false) / 1_048_576f;
            GUI.Label(new Rect(10, y, 200, lineH), $"GC Mem: {memMB:F1} MB", _style);
            y += lineH;

            // Target FPS info
            int tgt = Application.targetFrameRate;
            GUI.Label(new Rect(10, y, 240, lineH),
                $"Target FPS: {(tgt <= 0 ? "unlimited" : tgt.ToString())}", _style);
            y += lineH;

            // Build label
            GUI.color = Color.cyan;
            GUI.Label(new Rect(10, y, 320, lineH),
                "SOHIBQIRON Phase 02.1 | Unity 2022.3.21f1", _style);

            GUI.color = Color.white;
        }
    }
}
