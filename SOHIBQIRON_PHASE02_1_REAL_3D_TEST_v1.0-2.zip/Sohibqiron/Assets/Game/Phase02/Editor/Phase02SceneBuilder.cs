// Phase02SceneBuilder.cs
// SOHIBQIRON - PHASE 02.1
// Unity Editor menu: Sohibqiron > Phase02 > Build Test Scene
//
// FIX LOG (Phase02.1 Fix):
//   FIXED: camera target not assigned — now calls camCtrl.SetTarget(player.transform)
//   ADDED: Phase02PerformanceHUD added to a dedicated manager GameObject
//   ADDED: Phase02TouchInputBridge added with correct references
//   CLEANED: no duplicate camera systems
//
// FIX LOG (Camera Fix Pass):
//   FIXED: touchBridge reference on Phase02CameraController was never assigned.
//          Now calls camCtrl.SetTouchBridge(touch) after bridge is created.
//          Relationship: TouchBridge → PlayerController + CameraController
//                        CameraController.touchBridge → TouchBridge (same instance)

#if UNITY_EDITOR
using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine.SceneManagement;

namespace Sohibqiron.Phase02.Editor
{
    public static class Phase02SceneBuilder
    {
        [MenuItem("Sohibqiron/Phase02/Build Test Scene")]
        public static void BuildTestScene()
        {
            // --- New empty scene ---
            EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            Scene scene = SceneManager.GetActiveScene();
            Debug.Log("[Phase02Builder] Building Phase 02.1 test scene...");

            // ------------------------------------------------------------------
            // 1. DIRECTIONAL LIGHT
            // ------------------------------------------------------------------
            GameObject lightGO = new GameObject("Directional Light");
            Light light        = lightGO.AddComponent<Light>();
            light.type         = LightType.Directional;
            light.intensity    = 1.2f;
            light.color        = new Color(1f, 0.97f, 0.88f);
            light.shadows      = LightShadows.Soft;
            lightGO.transform.rotation = Quaternion.Euler(45f, -30f, 0f);
            Debug.Log("[Phase02Builder] ✓ Directional Light");

            // ------------------------------------------------------------------
            // 2. GROUND PLANE
            // ------------------------------------------------------------------
            GameObject ground      = GameObject.CreatePrimitive(PrimitiveType.Plane);
            ground.name            = "Ground";
            ground.transform.localScale = new Vector3(10f, 1f, 10f); // 100 x 100 units
            Renderer groundRend    = ground.GetComponent<Renderer>();
            Material groundMat     = new Material(Shader.Find("Standard"));
            groundMat.color        = new Color(0.4f, 0.55f, 0.35f);
            groundRend.material    = groundMat;
            // MeshCollider already created by CreatePrimitive — leave it
            Debug.Log("[Phase02Builder] ✓ Ground (100x100)");

            // ------------------------------------------------------------------
            // 3. PLAYER (blue Capsule + CharacterController + Phase02PlayerController)
            // ------------------------------------------------------------------
            GameObject player = GameObject.CreatePrimitive(PrimitiveType.Capsule);
            player.name       = "Player";
            player.transform.position = new Vector3(0f, 1f, 0f);

            // CharacterController replaces CapsuleCollider
            Object.DestroyImmediate(player.GetComponent<CapsuleCollider>());
            CharacterController cc = player.AddComponent<CharacterController>();
            cc.height = 1.8f;
            cc.radius = 0.35f;
            cc.center = Vector3.zero;

            player.AddComponent<Phase02PlayerController>();

            Renderer playerRend = player.GetComponent<Renderer>();
            Material playerMat  = new Material(Shader.Find("Standard"));
            playerMat.color     = new Color(0.2f, 0.4f, 0.8f);
            playerRend.material = playerMat;
            Debug.Log("[Phase02Builder] ✓ Player Capsule");

            // ------------------------------------------------------------------
            // 4. MAIN CAMERA + Phase02CameraController (target assigned here)
            // ------------------------------------------------------------------
            GameObject camGO = new GameObject("Main Camera");
            Camera cam       = camGO.AddComponent<Camera>();
            cam.tag          = "MainCamera";
            cam.fieldOfView  = 65f;
            cam.nearClipPlane = 0.1f;
            cam.farClipPlane  = 500f;
            camGO.AddComponent<AudioListener>();

            Phase02CameraController camCtrl = camGO.AddComponent<Phase02CameraController>();

            // FIX: assign Player transform as camera target
            camCtrl.SetTarget(player.transform);

            camGO.transform.position = new Vector3(0f, 5f, -8f);
            camGO.transform.LookAt(player.transform.position + Vector3.up * 1.4f);
            Debug.Log("[Phase02Builder] ✓ Main Camera (target → Player)");

            // ------------------------------------------------------------------
            // 5. GAME MANAGER (PerformanceHUD + TouchInputBridge)
            // ------------------------------------------------------------------
            GameObject mgr = new GameObject("Phase02_GameManager");

            Phase02PerformanceHUD hud = mgr.AddComponent<Phase02PerformanceHUD>();

            Phase02TouchInputBridge touch = mgr.AddComponent<Phase02TouchInputBridge>();

            // Wire TouchBridge → PlayerController and CameraController
            SerializedObject soTouch = new SerializedObject(touch);
            soTouch.FindProperty("playerController")
                   .objectReferenceValue = player.GetComponent<Phase02PlayerController>();
            soTouch.FindProperty("cameraController")
                   .objectReferenceValue = camCtrl;
            soTouch.ApplyModifiedPropertiesWithoutUndo();

            // FIX: wire CameraController → TouchBridge (same single instance)
            // Phase02CameraController.touchBridge was previously unassigned.
            camCtrl.SetTouchBridge(touch);

            Debug.Log("[Phase02Builder] ✓ GameManager (PerformanceHUD + TouchInputBridge)");
            Debug.Log("[Phase02Builder] ✓ CameraController.touchBridge → TouchBridge");

            // ------------------------------------------------------------------
            // 6. OBSTACLES  (collision test)
            // ------------------------------------------------------------------
            CreateObstacle("Rock_1", new Vector3( 5f, 0.5f,  5f), new Vector3(1.5f, 1f, 1.5f), new Color(0.5f, 0.45f, 0.4f));
            CreateObstacle("Rock_2", new Vector3(-6f, 0.5f,  3f), new Vector3(2.0f, 1f, 1.0f), new Color(0.5f, 0.45f, 0.4f));
            CreateObstacle("Rock_3", new Vector3( 3f, 0.5f, -7f), new Vector3(1.0f, 1f, 2.0f), new Color(0.5f, 0.45f, 0.4f));
            CreateObstacle("Wall_1", new Vector3( 0f, 1.0f, 12f), new Vector3(8.0f, 2f, 0.5f), new Color(0.7f, 0.65f, 0.55f));
            Debug.Log("[Phase02Builder] ✓ Obstacles");

            // ------------------------------------------------------------------
            // 7. SAVE SCENE
            // ------------------------------------------------------------------
            string scenePath = "Assets/Game/Scenes/Phase02_TestScene.unity";
            EditorSceneManager.SaveScene(scene, scenePath);

            Debug.Log("[Phase02Builder] ====================================");
            Debug.Log($"[Phase02Builder] Scene saved: {scenePath}");
            Debug.Log("[Phase02Builder] Play ▶, use WASD to move.");
            Debug.Log("[Phase02Builder] Right-click drag = rotate camera.");
            Debug.Log("[Phase02Builder] Mouse scroll     = zoom.");
            Debug.Log("[Phase02Builder] ====================================");

            Selection.activeGameObject = player;
        }

        // ------------------------------------------------------------------
        private static void CreateObstacle(string objName, Vector3 pos,
                                            Vector3 scale, Color color)
        {
            GameObject go     = GameObject.CreatePrimitive(PrimitiveType.Cube);
            go.name           = objName;
            go.transform.position   = pos;
            go.transform.localScale = scale;
            Material mat  = new Material(Shader.Find("Standard"));
            mat.color     = color;
            go.GetComponent<Renderer>().material = mat;
        }
    }
}
#endif
