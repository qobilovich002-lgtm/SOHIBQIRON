// PlayerController.cs
// Joylashuv: Assets/Game/Characters/Player/Scripts/
// O'yinchi 3D harakati — CharacterController bilan

using UnityEngine;
using Sohibqiron.InputSystem;
using Sohibqiron.CameraSystem;

namespace Sohibqiron.Characters.Player
{
    [RequireComponent(typeof(CharacterController))]
    [RequireComponent(typeof(PlayerAnimationController))]
    public class PlayerController : MonoBehaviour
    {
        [Header("Harakat sozlamalari")]
        [SerializeField] private float walkSpeed = 3.5f;
        [SerializeField] private float runSpeed = 6.0f;
        [SerializeField] private float sprintSpeed = 9.0f;
        [SerializeField] private float jumpForce = 5.5f;
        [SerializeField] private float gravity = -18f;
        [SerializeField] private float rotationSpeed = 12f;
        [SerializeField] private float groundCheckRadius = 0.3f;
        [SerializeField] private LayerMask groundLayer;

        [Header("Stamina")]
        [SerializeField] private float maxStamina = 100f;
        [SerializeField] private float staminaDrainRate = 20f;
        [SerializeField] private float staminaRegenRate = 15f;
        [SerializeField] private float sprintStaminaCost = 25f;

        // Komponentlar
        private CharacterController _characterController;
        private PlayerAnimationController _animController;
        private InputManager _inputManager;
        private CameraManager _cameraManager;
        private UnityEngine.Camera _mainCamera;

        // Harakat holati
        private Vector3 _velocity;
        private Vector3 _moveDirection;
        private float _currentSpeed;
        private float _currentStamina;
        private bool _isGrounded;
        private bool _isSprinting;
        private bool _isJumping;
        private bool _isDodging;
        private float _dodgeTimer;
        private const float DodgeDuration = 0.4f;

        // Xususiyatlar (Properties)
        public float CurrentStamina => _currentStamina;
        public float MaxStamina => maxStamina;
        public bool IsGrounded => _isGrounded;
        public bool IsSprinting => _isSprinting;
        public bool IsMoving => _moveDirection.magnitude > 0.1f;
        public Vector3 MoveDirection => _moveDirection;

        // Hodisalar
        public static event System.Action OnJump;
        public static event System.Action OnDodge;
        public static event System.Action OnLand;

        private void Awake()
        {
            _characterController = GetComponent<CharacterController>();
            _animController = GetComponent<PlayerAnimationController>();
            _currentStamina = maxStamina;
        }

        private void Start()
        {
            _inputManager = InputManager.Instance;
            _cameraManager = CameraManager.Instance;
            _mainCamera = UnityEngine.Camera.main;

            if (_inputManager == null)
                Debug.LogError("[PlayerController] InputManager topilmadi!");
            if (_mainCamera == null)
                Debug.LogError("[PlayerController] Main Camera topilmadi!");
        }

        private void Update()
        {
            CheckGround();
            HandleMovement();
            HandleJump();
            HandleDodge();
            HandleStamina();
            ApplyGravity();
        }

        private void CheckGround()
        {
            Vector3 spherePos = transform.position + Vector3.down * (_characterController.height / 2f - groundCheckRadius);
            bool wasGrounded = _isGrounded;
            _isGrounded = Physics.CheckSphere(spherePos, groundCheckRadius, groundLayer);

            if (!wasGrounded && _isGrounded)
            {
                OnLand?.Invoke();
                _animController?.SetLanding();
            }
        }

        private void HandleMovement()
        {
            if (_isDodging) return;

            // Input olish
            Vector2 input = Vector2.zero;
            if (_inputManager != null)
                input = _inputManager.MoveInput;

            // Kamera yo'nalishiga qarab harakat
            Vector3 cameraForward = Vector3.zero;
            Vector3 cameraRight = Vector3.zero;

            if (_mainCamera != null)
            {
                cameraForward = _mainCamera.transform.forward;
                cameraRight = _mainCamera.transform.right;
                cameraForward.y = 0f;
                cameraRight.y = 0f;
                cameraForward.Normalize();
                cameraRight.Normalize();
            }

            _moveDirection = (cameraForward * input.y + cameraRight * input.x);
            _moveDirection = Vector3.ClampMagnitude(_moveDirection, 1f);

            // Tezlik hisoblash
            bool wantSprint = _inputManager != null && _inputManager.SprintHeld && _currentStamina > 0f;
            _isSprinting = wantSprint && _moveDirection.magnitude > 0.5f;

            if (_isSprinting)
                _currentSpeed = sprintSpeed;
            else if (_moveDirection.magnitude > 0.1f)
                _currentSpeed = runSpeed;
            else
                _currentSpeed = 0f;

            // Harakatni qo'llash
            Vector3 move = _moveDirection * _currentSpeed * Time.deltaTime;
            _characterController.Move(move);

            // Personajni aylantirish
            if (_moveDirection.magnitude > 0.1f)
            {
                Quaternion targetRot = Quaternion.LookRotation(_moveDirection);
                transform.rotation = Quaternion.Slerp(transform.rotation, targetRot, rotationSpeed * Time.deltaTime);
            }

            // Animatsiya yangilash
            _animController?.UpdateMovement(_moveDirection.magnitude, _isSprinting);
        }

        private void HandleJump()
        {
            if (_inputManager == null) return;
            if (_inputManager.JumpPressed && _isGrounded && !_isDodging)
            {
                _velocity.y = Mathf.Sqrt(jumpForce * -2f * gravity);
                _isJumping = true;
                OnJump?.Invoke();
                _animController?.TriggerJump();
            }
        }

        private void HandleDodge()
        {
            if (_inputManager == null) return;

            if (_isDodging)
            {
                _dodgeTimer -= Time.deltaTime;
                Vector3 dodgeMove = _moveDirection.magnitude > 0.1f
                    ? _moveDirection * 8f * Time.deltaTime
                    : -transform.forward * 8f * Time.deltaTime;
                _characterController.Move(dodgeMove);

                if (_dodgeTimer <= 0f)
                    _isDodging = false;
                return;
            }

            if (_inputManager.DodgePressed && _isGrounded && _currentStamina >= 20f)
            {
                _isDodging = true;
                _dodgeTimer = DodgeDuration;
                _currentStamina -= 20f;
                OnDodge?.Invoke();
                _animController?.TriggerDodge();
            }
        }

        private void HandleStamina()
        {
            if (_isSprinting)
                _currentStamina = Mathf.Max(0f, _currentStamina - staminaDrainRate * Time.deltaTime);
            else
                _currentStamina = Mathf.Min(maxStamina, _currentStamina + staminaRegenRate * Time.deltaTime);
        }

        private void ApplyGravity()
        {
            if (_isGrounded && _velocity.y < 0f)
                _velocity.y = -2f;

            _velocity.y += gravity * Time.deltaTime;
            _characterController.Move(_velocity * Time.deltaTime);
        }

        // Debug vizual
        private void OnDrawGizmosSelected()
        {
            if (_characterController == null) return;
            Gizmos.color = _isGrounded ? Color.green : Color.red;
            Vector3 spherePos = transform.position + Vector3.down * (_characterController.height / 2f - groundCheckRadius);
            Gizmos.DrawWireSphere(spherePos, groundCheckRadius);
        }
    }
}
