// PlayerAnimationController.cs
// Joylashuv: Assets/Game/Characters/Player/Scripts/
// Animator state machine boshqaruvi

using UnityEngine;

namespace Sohibqiron.Characters.Player
{
    [RequireComponent(typeof(Animator))]
    public class PlayerAnimationController : MonoBehaviour
    {
        private Animator _animator;

        // Animator parametrlari (string o'rniga hash — tezroq)
        private static readonly int SpeedHash       = Animator.StringToHash("Speed");
        private static readonly int IsSprintingHash = Animator.StringToHash("IsSprinting");
        private static readonly int IsGroundedHash  = Animator.StringToHash("IsGrounded");
        private static readonly int JumpHash        = Animator.StringToHash("Jump");
        private static readonly int DodgeHash       = Animator.StringToHash("Dodge");
        private static readonly int AttackHash      = Animator.StringToHash("Attack");
        private static readonly int HitHash         = Animator.StringToHash("Hit");
        private static readonly int DeathHash       = Animator.StringToHash("Death");
        private static readonly int LandHash        = Animator.StringToHash("Land");

        [Header("Yumshoq o'tish tezligi")]
        [SerializeField] private float speedDampTime = 0.1f;

        private void Awake()
        {
            _animator = GetComponent<Animator>();
            if (_animator == null)
                Debug.LogError("[PlayerAnimationController] Animator topilmadi!");
        }

        public void UpdateMovement(float speed, bool isSprinting)
        {
            _animator.SetFloat(SpeedHash, speed, speedDampTime, Time.deltaTime);
            _animator.SetBool(IsSprintingHash, isSprinting);
        }

        public void SetGrounded(bool grounded)
        {
            _animator.SetBool(IsGroundedHash, grounded);
        }

        public void TriggerJump()
        {
            _animator.SetTrigger(JumpHash);
            _animator.SetBool(IsGroundedHash, false);
        }

        public void SetLanding()
        {
            _animator.SetBool(IsGroundedHash, true);
            _animator.SetTrigger(LandHash);
        }

        public void TriggerDodge()
        {
            _animator.SetTrigger(DodgeHash);
        }

        public void TriggerAttack(int comboIndex = 0)
        {
            _animator.SetTrigger(AttackHash);
        }

        public void TriggerHit()
        {
            _animator.SetTrigger(HitHash);
        }

        public void TriggerDeath()
        {
            _animator.SetTrigger(DeathHash);
            _animator.SetBool(IsGroundedHash, true);
        }

        // Animator hodisa chaqiruvlari (animation event)
        public void OnAttackStart()  { /* Qilich chiqarish */ }
        public void OnAttackEnd()    { /* Qilich yashirish */ }
        public void OnFootstepLeft() { /* Chap oyoq ovozi */ }
        public void OnFootstepRight(){ /* O'ng oyoq ovozi */ }
    }
}
