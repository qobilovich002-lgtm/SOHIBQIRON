// GraphicsSettingsManager.cs
// Joylashuv: Assets/Game/Settings/
// Low / Medium / High / Ultra grafika tizimi + avtomatik aniqlash

using UnityEngine;
using UnityEngine.Rendering;

namespace Sohibqiron.Settings
{
    public class GraphicsSettingsManager : MonoBehaviour
    {
        public static GraphicsSettingsManager Instance { get; private set; }

        [Header("Standart sozlamalar")]
        [SerializeField] private GraphicsQuality defaultQuality = GraphicsQuality.Medium;
        [SerializeField] private bool autoDetectOnFirstRun = true;

        // Hozirgi sozlamalar
        public GraphicsSettings CurrentSettings { get; private set; }

        private const string SaveKey = "GraphicsSettings";

        private void Awake()
        {
            if (Instance != null && Instance != this) { Destroy(gameObject); return; }
            Instance = this;
            DontDestroyOnLoad(gameObject);
            LoadOrInitSettings();
        }

        private void LoadOrInitSettings()
        {
            if (PlayerPrefs.HasKey(SaveKey))
            {
                string json = PlayerPrefs.GetString(SaveKey);
                CurrentSettings = JsonUtility.FromJson<GraphicsSettings>(json);
            }
            else
            {
                GraphicsQuality detected = autoDetectOnFirstRun ? AutoDetectQuality() : defaultQuality;
                CurrentSettings = GraphicsSettings.FromPreset(detected);
            }
            ApplySettings();
        }

        private GraphicsQuality AutoDetectQuality()
        {
            int ram = SystemInfo.systemMemorySize;
            string gpu = SystemInfo.graphicsDeviceName.ToLower();

            // Oddiy aniqlash — keyinchalik kengaytirish mumkin
            if (ram >= 6000) return GraphicsQuality.High;
            if (ram >= 4000) return GraphicsQuality.Medium;
            return GraphicsQuality.Low;
        }

        public void ApplySettings()
        {
            var s = CurrentSettings;

            // Ekran aniqligi
            float scale = s.ResolutionScale;
            Screen.SetResolution(
                Mathf.RoundToInt(Display.main.systemWidth * scale),
                Mathf.RoundToInt(Display.main.systemHeight * scale),
                true);

            // Unity sifat darajasi
            QualitySettings.SetQualityLevel((int)s.Quality, true);

            // Shadows
            QualitySettings.shadows = s.ShadowQuality switch
            {
                ShadowLevel.Off    => ShadowQuality.Disable,
                ShadowLevel.Low    => ShadowQuality.HardOnly,
                ShadowLevel.Medium => ShadowQuality.All,
                ShadowLevel.High   => ShadowQuality.All,
                _                  => ShadowQuality.HardOnly
            };
            QualitySettings.shadowDistance = s.ShadowQuality switch
            {
                ShadowLevel.Off    => 0f,
                ShadowLevel.Low    => 30f,
                ShadowLevel.Medium => 60f,
                ShadowLevel.High   => 120f,
                _                  => 30f
            };

            // Frame rate
            Application.targetFrameRate = s.TargetFPS;
            QualitySettings.vSyncCount = 0;

            // LOD
            QualitySettings.lodBias = s.Quality switch
            {
                GraphicsQuality.Low   => 0.4f,
                GraphicsQuality.Medium=> 0.7f,
                GraphicsQuality.High  => 1.0f,
                GraphicsQuality.Ultra => 1.5f,
                _                     => 0.7f
            };

            Debug.Log($"[Graphics] {s.Quality} sifat qo'llanildi. FPS maqsad: {s.TargetFPS}");
            SaveSettings();
        }

        public void SetPreset(GraphicsQuality preset)
        {
            CurrentSettings = GraphicsSettings.FromPreset(preset);
            ApplySettings();
        }

        private void SaveSettings()
        {
            PlayerPrefs.SetString(SaveKey, JsonUtility.ToJson(CurrentSettings));
            PlayerPrefs.Save();
        }
    }

    // ─── Ma'lumot tuzilmalari ───────────────────────────────

    public enum GraphicsQuality { Low, Medium, High, Ultra }
    public enum ShadowLevel     { Off, Low, Medium, High }

    [System.Serializable]
    public class GraphicsSettings
    {
        public GraphicsQuality Quality;
        public float  ResolutionScale;
        public ShadowLevel ShadowQuality;
        public bool   PostProcessing;
        public bool   AntiAliasing;
        public int    TargetFPS;
        public float  ViewDistance;

        public static GraphicsSettings FromPreset(GraphicsQuality q) => q switch
        {
            GraphicsQuality.Low    => new() { Quality=q, ResolutionScale=0.65f, ShadowQuality=ShadowLevel.Off,  PostProcessing=false,AntiAliasing=false,TargetFPS=30,  ViewDistance=150f },
            GraphicsQuality.Medium => new() { Quality=q, ResolutionScale=0.80f, ShadowQuality=ShadowLevel.Low,  PostProcessing=false,AntiAliasing=false,TargetFPS=30,  ViewDistance=250f },
            GraphicsQuality.High   => new() { Quality=q, ResolutionScale=1.00f, ShadowQuality=ShadowLevel.Medium,PostProcessing=true, AntiAliasing=true, TargetFPS=60,  ViewDistance=400f },
            GraphicsQuality.Ultra  => new() { Quality=q, ResolutionScale=1.00f, ShadowQuality=ShadowLevel.High, PostProcessing=true, AntiAliasing=true, TargetFPS=60,  ViewDistance=600f },
            _                      => FromPreset(GraphicsQuality.Medium)
        };
    }
}
