// SaveSystem.cs
// Joylashuv: Assets/Game/SaveSystem/
// Autosave + checkpoint + manual save

using UnityEngine;
using System.IO;

namespace Sohibqiron.SaveSystem
{
    public class SaveSystem : MonoBehaviour
    {
        public static SaveSystem Instance { get; private set; }

        [Header("Saqlash sozlamalari")]
        [SerializeField] private float autosaveInterval = 120f; // 2 daqiqa
        [SerializeField] private int maxManualSlots = 3;

        private float _autosaveTimer;
        private string SavePath => Path.Combine(Application.persistentDataPath, "Saves");

        private void Awake()
        {
            if (Instance != null && Instance != this) { Destroy(gameObject); return; }
            Instance = this;
            DontDestroyOnLoad(gameObject);
            Directory.CreateDirectory(SavePath);
        }

        private void Update()
        {
            _autosaveTimer += Time.deltaTime;
            if (_autosaveTimer >= autosaveInterval)
            {
                _autosaveTimer = 0f;
                AutoSave();
            }
        }

        public void AutoSave()
        {
            SaveData data = CollectSaveData("autosave");
            WriteToFile("autosave.json", data);
            Debug.Log("[SaveSystem] Avtosaqlash amalga oshirildi.");
        }

        public void SaveCheckpoint(string checkpointId)
        {
            SaveData data = CollectSaveData(checkpointId);
            WriteToFile("checkpoint.json", data);
            Debug.Log($"[SaveSystem] Checkpoint saqlandi: {checkpointId}");
        }

        public void ManualSave(int slot)
        {
            if (slot < 0 || slot >= maxManualSlots) return;
            SaveData data = CollectSaveData($"manual_{slot}");
            WriteToFile($"manual_{slot}.json", data);
            Debug.Log($"[SaveSystem] Qo'lda saqlandi: slot {slot}");
        }

        public SaveData LoadSave(string filename)
        {
            string path = Path.Combine(SavePath, filename);
            if (!File.Exists(path)) return null;
            string json = File.ReadAllText(path);
            return JsonUtility.FromJson<SaveData>(json);
        }

        private SaveData CollectSaveData(string saveId)
        {
            return new SaveData
            {
                SaveId        = saveId,
                SaveTime      = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
                CurrentScene  = UnityEngine.SceneManagement.SceneManager.GetActiveScene().name,
                // PlayerPosition va boshqalar keyinchalik qo'shiladi
            };
        }

        private void WriteToFile(string filename, SaveData data)
        {
            string json = JsonUtility.ToJson(data, prettyPrint: true);
            File.WriteAllText(Path.Combine(SavePath, filename), json);
        }
    }

    [System.Serializable]
    public class SaveData
    {
        public string   SaveId;
        public string   SaveTime;
        public string   CurrentScene;
        public float    PlayerHP;
        public float    PlayerStamina;
        public int      PlayerAmmo;
        public Vector3  PlayerPosition;
        public float    PlayerRotationY;
        public int      CurrentChapter;
        public string   CurrentMission;
        public bool[]   CompletedMissions;
        public int      PlaytimeSeconds;
    }
}
