// AudioManager.cs
// Joylashuv: Assets/Game/Audio/
// Musiqa, SFX, muhit ovozlari — alohida kanallar

using UnityEngine;
using System.Collections.Generic;

namespace Sohibqiron.Audio
{
    public class AudioManager : MonoBehaviour
    {
        public static AudioManager Instance { get; private set; }

        [Header("Audio manbalar")]
        [SerializeField] private AudioSource musicSource;
        [SerializeField] private AudioSource ambientSource;
        [SerializeField] private AudioSource sfxSource;
        [SerializeField] private AudioSource voiceSource;

        [Header("Standart balandlik")]
        [SerializeField, Range(0,1)] private float masterVolume  = 1f;
        [SerializeField, Range(0,1)] private float musicVolume   = 0.7f;
        [SerializeField, Range(0,1)] private float sfxVolume     = 1f;
        [SerializeField, Range(0,1)] private float voiceVolume   = 1f;
        [SerializeField, Range(0,1)] private float ambientVolume = 0.5f;

        // SFX pool
        private List<AudioSource> _sfxPool = new();
        private const int PoolSize = 12;

        private void Awake()
        {
            if (Instance != null && Instance != this) { Destroy(gameObject); return; }
            Instance = this;
            DontDestroyOnLoad(gameObject);
            InitPool();
            LoadVolumes();
        }

        private void InitPool()
        {
            for (int i = 0; i < PoolSize; i++)
            {
                var go = new GameObject($"SFX_Pool_{i}");
                go.transform.SetParent(transform);
                var src = go.AddComponent<AudioSource>();
                src.playOnAwake = false;
                src.spatialBlend = 0f;
                _sfxPool.Add(src);
            }
        }

        // ─── Ommaviy metodlar ────────────────────────────────

        public void PlayMusic(AudioClip clip, float fadeDuration = 1f, bool loop = true)
        {
            if (musicSource.clip == clip) return;
            StartCoroutine(CrossfadeMusic(clip, fadeDuration, loop));
        }

        public void PlaySFX(AudioClip clip, float volumeScale = 1f)
        {
            if (clip == null) return;
            var src = GetFreeSFXSource();
            if (src == null) { sfxSource.PlayOneShot(clip, sfxVolume * masterVolume * volumeScale); return; }
            src.clip = clip;
            src.volume = sfxVolume * masterVolume * volumeScale;
            src.Play();
        }

        public void PlaySFXAt(AudioClip clip, Vector3 position, float volumeScale = 1f)
        {
            if (clip == null) return;
            AudioSource.PlayClipAtPoint(clip, position, sfxVolume * masterVolume * volumeScale);
        }

        public void PlayAmbient(AudioClip clip, bool loop = true)
        {
            ambientSource.clip = clip;
            ambientSource.loop = loop;
            ambientSource.volume = ambientVolume * masterVolume;
            ambientSource.Play();
        }

        public void PlayVoice(AudioClip clip)
        {
            voiceSource.clip = clip;
            voiceSource.volume = voiceVolume * masterVolume;
            voiceSource.Play();
        }

        // Ovoz balandliklarini o'rnatish
        public void SetMasterVolume(float v) { masterVolume = v; ApplyVolumes(); SaveVolumes(); }
        public void SetMusicVolume(float v)  { musicVolume  = v; ApplyVolumes(); SaveVolumes(); }
        public void SetSFXVolume(float v)    { sfxVolume    = v; SaveVolumes(); }
        public void SetVoiceVolume(float v)  { voiceVolume  = v; ApplyVolumes(); SaveVolumes(); }

        private void ApplyVolumes()
        {
            if (musicSource)  musicSource.volume  = musicVolume  * masterVolume;
            if (ambientSource)ambientSource.volume = ambientVolume * masterVolume;
            if (voiceSource)  voiceSource.volume  = voiceVolume  * masterVolume;
        }

        private AudioSource GetFreeSFXSource()
        {
            foreach (var src in _sfxPool)
                if (!src.isPlaying) return src;
            return null;
        }

        private System.Collections.IEnumerator CrossfadeMusic(AudioClip newClip, float dur, bool loop)
        {
            float t = 0f;
            float startVol = musicSource.volume;
            while (t < dur / 2f)
            {
                t += Time.unscaledDeltaTime;
                musicSource.volume = Mathf.Lerp(startVol, 0f, t / (dur / 2f));
                yield return null;
            }
            musicSource.clip = newClip;
            musicSource.loop = loop;
            musicSource.Play();
            t = 0f;
            float targetVol = musicVolume * masterVolume;
            while (t < dur / 2f)
            {
                t += Time.unscaledDeltaTime;
                musicSource.volume = Mathf.Lerp(0f, targetVol, t / (dur / 2f));
                yield return null;
            }
        }

        private void SaveVolumes()
        {
            PlayerPrefs.SetFloat("Vol_Master",  masterVolume);
            PlayerPrefs.SetFloat("Vol_Music",   musicVolume);
            PlayerPrefs.SetFloat("Vol_SFX",     sfxVolume);
            PlayerPrefs.SetFloat("Vol_Voice",   voiceVolume);
            PlayerPrefs.SetFloat("Vol_Ambient", ambientVolume);
        }

        private void LoadVolumes()
        {
            masterVolume  = PlayerPrefs.GetFloat("Vol_Master",  1.0f);
            musicVolume   = PlayerPrefs.GetFloat("Vol_Music",   0.7f);
            sfxVolume     = PlayerPrefs.GetFloat("Vol_SFX",     1.0f);
            voiceVolume   = PlayerPrefs.GetFloat("Vol_Voice",   1.0f);
            ambientVolume = PlayerPrefs.GetFloat("Vol_Ambient", 0.5f);
            ApplyVolumes();
        }
    }
}
