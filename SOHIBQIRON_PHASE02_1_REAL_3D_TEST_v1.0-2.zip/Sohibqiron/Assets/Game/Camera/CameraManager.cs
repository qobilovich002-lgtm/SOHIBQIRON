// CameraManager.cs
// Joylashuv: Assets/Game/Camera/
// Third-person, combat, cinematic kamera tizimi

using UnityEngine;

namespace Sohibqiron.CameraSystem
{
    public class CameraManager : MonoBehaviour
    {
        public static CameraManager Instance { get; private set; }

        [Header("Maqsad")]
        [SerializeField] private Transform target;
        [SerializeField] private Vector3 targetOffset = new Vector3(0f, 1.6f, 0f);

        [Header("Masofa")]
        [SerializeField] private float defaultDistance = 4.5f;
        [SerializeField] private float minDistance = 1.5f;
        [SerializeField] private float maxDistance = 10f;
        [SerializeField] private float zoomSpeed = 2f;

        [Header("Burchak")]
        [SerializeField] private float defaultPitch = 15f;
        [SerializeField] private float minPitch = -20f;
        [SerializeField] private float maxPitch = 70f;

        [Header("Sezgirlik")]
        [SerializeField] private float touchSensitivity = 0.3f;
        [SerializeField] private float mouseSensitivity = 2.5f;

        [Header("Yumshoqlik")]
        [SerializeField] private float positionSmoothing = 8f;
        [SerializeField] private float rotationSmoothing = 10f;

        [Header("Kamera to'qnashuvi")]
        [SerializeField] private LayerMask collisionLayers;
        [SerializeField] private float collisionRadius = 0.3f;
        [SerializeField] private float collisionOffset = 0.2f;

        [Header("Kamera silkinishi")]
        [SerializeField] private float shakeDecay = 5f;

        // Hozirgi holat
        private float _currentYaw;
        private float _currentPitch;
        private float _currentDistance;
        private float _targetDistance;
        private Vector3 _shakeOffset;
        private float _shakeIntensity;
        private CameraMode _currentMode = CameraMode.ThirdPerson;

        private UnityEngine.Camera _cam;

        public CameraMode CurrentMode => _currentMode;

        private void Awake()
        {
            if (Instance != null && Instance != this) { Destroy(gameObject); return; }
            Instance = this;
            _cam = GetComponent<UnityEngine.Camera>() ?? UnityEngine.Camera.main;
            _currentDistance = defaultDistance;
            _targetDistance = defaultDistance;
            _currentPitch = defaultPitch;
        }

        private void LateUpdate()
        {
            if (target == null) return;

            UpdateShake();

            switch (_currentMode)
            {
                case CameraMode.ThirdPerson: UpdateThirdPerson(); break;
                case CameraMode.Cinematic:   UpdateCinematic();   break;
            }
        }

        private void UpdateThirdPerson()
        {
            // Input olish
            Vector2 lookInput = Sohibqiron.InputSystem.InputManager.Instance != null
                ? Sohibqiron.InputSystem.InputManager.Instance.LookInput
                : Vector2.zero;

            float sensitivity = Application.isMobilePlatform ? touchSensitivity : mouseSensitivity;

            _currentYaw   += lookInput.x * sensitivity;
            _currentPitch -= lookInput.y * sensitivity;
            _currentPitch = Mathf.Clamp(_currentPitch, minPitch, maxPitch);

            // Zoom (pinch-to-zoom keyinchalik)
            _currentDistance = Mathf.Lerp(_currentDistance, _targetDistance, zoomSpeed * Time.deltaTime);

            // Maqsad pozitsiyasi
            Vector3 pivotPos = target.position + targetOffset;

            // Kamera pozitsiyasi hisoblash
            Quaternion rotation = Quaternion.Euler(_currentPitch, _currentYaw, 0f);
            Vector3 desiredPos = pivotPos - rotation * Vector3.forward * _currentDistance;

            // To'qnashuv tekshirish
            float actualDistance = CheckCameraCollision(pivotPos, desiredPos);
            Vector3 finalPos = pivotPos - rotation * Vector3.forward * actualDistance;

            // Yumshoq harakat
            transform.position = Vector3.Lerp(transform.position, finalPos + _shakeOffset, positionSmoothing * Time.deltaTime);
            transform.LookAt(pivotPos);
        }

        private float CheckCameraCollision(Vector3 from, Vector3 to)
        {
            Vector3 dir = to - from;
            float dist = dir.magnitude;

            if (Physics.SphereCast(from, collisionRadius, dir.normalized, out RaycastHit hit, dist, collisionLayers))
                return hit.distance - collisionOffset;

            return _currentDistance;
        }

        private void UpdateCinematic()
        {
            // Cinematic holat keyinchalik to'ldiriladi
        }

        private void UpdateShake()
        {
            if (_shakeIntensity > 0f)
            {
                _shakeOffset = Random.insideUnitSphere * _shakeIntensity;
                _shakeIntensity = Mathf.Lerp(_shakeIntensity, 0f, shakeDecay * Time.deltaTime);
                if (_shakeIntensity < 0.01f) { _shakeIntensity = 0f; _shakeOffset = Vector3.zero; }
            }
        }

        // Ommaviy metodlar
        public void SetTarget(Transform newTarget) => target = newTarget;

        public void TriggerShake(float intensity)
        {
            _shakeIntensity = Mathf.Max(_shakeIntensity, intensity);
        }

        public void SetMode(CameraMode mode)
        {
            _currentMode = mode;
            Debug.Log($"[CameraManager] Rejim: {mode}");
        }

        public void SetYaw(float yaw) => _currentYaw = yaw;
        public float GetYaw() => _currentYaw;
    }

    public enum CameraMode
    {
        ThirdPerson,
        Combat,
        Aiming,
        Horse,
        Cinematic,
        Fixed
    }
}
