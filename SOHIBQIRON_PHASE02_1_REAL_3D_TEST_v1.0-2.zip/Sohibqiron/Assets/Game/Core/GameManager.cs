// GameManager.cs
// Joylashuv: Assets/Game/Core/
// Asosiy o'yin menejeri — singleton pattern

using UnityEngine;
using Sohibqiron.Audio;
using Sohibqiron.SaveSystem;
using Sohibqiron.Settings;
using Sohibqiron.Localization;

namespace Sohibqiron.Core
{
    public class GameManager : MonoBehaviour
    {
        // Singleton
        public static GameManager Instance { get; private set; }

        [Header("O'yin holati")]
        public GameState CurrentState { get; private set; } = GameState.MainMenu;

        [Header("Tizimlar (Inspector'dan bog'lang)")]
        [SerializeField] private AudioManager audioManager;
        [SerializeField] private SaveSystem saveSystem;
        [SerializeField] private GraphicsSettingsManager settingsManager;
        [SerializeField] private LocalizationManager localizationManager;

        // Hodisalar (Events)
        public static event System.Action<GameState> OnGameStateChanged;

        private void Awake()
        {
            // Singleton sozlash
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }
            Instance = this;
            DontDestroyOnLoad(gameObject);

            InitializeSystems();
        }

        private void InitializeSystems()
        {
            Debug.Log("[GameManager] Tizimlar ishga tushirilmoqda...");
            // Tizimlar keyinchalik bu yerda boshlanadi
        }

        public void ChangeState(GameState newState)
        {
            CurrentState = newState;
            OnGameStateChanged?.Invoke(newState);
            Debug.Log($"[GameManager] Holat o'zgardi: {newState}");
        }

        public void StartNewGame()
        {
            ChangeState(GameState.Playing);
            UnityEngine.SceneManagement.SceneManager.LoadScene("Level_01_Samarkand");
        }

        public void PauseGame()
        {
            if (CurrentState == GameState.Playing)
            {
                ChangeState(GameState.Paused);
                Time.timeScale = 0f;
            }
        }

        public void ResumeGame()
        {
            if (CurrentState == GameState.Paused)
            {
                ChangeState(GameState.Playing);
                Time.timeScale = 1f;
            }
        }

        public void QuitGame()
        {
            Debug.Log("[GameManager] O'yin yopilmoqda...");
            Application.Quit();
        }
    }

    public enum GameState
    {
        MainMenu,
        Loading,
        Playing,
        Paused,
        Cinematic,
        GameOver,
        Victory
    }
}
