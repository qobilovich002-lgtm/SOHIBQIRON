# SOHIBQIRON — Unity Setup Ko'rsatmalari
## Phase 01: Test Sahnasi (v1.2 — Finalization)

---

## HOZIR NIMA TAYYOR / NIMA EMAS (v1.2)

**✅ Tayyor:**
- Barcha 11 ta skript `Assets/Game/...` strukturasida joylashgan va qo'lda (statik) tekshiruvdan o'tgan — namespace, `using`, klass/metod/event mosligida nomuvofiqlik topilmadi.
- `Packages/manifest.json`, `ProjectSettings/ProjectVersion.txt` mavjud va Phase 01 skriptlariga mos.
- Bundle identifier hujjatlarda izchil: `com.sohibqiron.riseoftimur` (probelsiz).
- Namespace xavfsizligi ta'minlangan: `Sohibqiron.InputSystem` / `Sohibqiron.CameraSystem` — `UnityEngine.Input` / `UnityEngine.Camera` bilan to'qnashmaydi.

**❌ Hali emas:**
- **Haqiqiy Unity compile tekshiruvi.** Ushbu ZIP shu muhitda (Unity Editor mavjud bo'lmagan holatda) tayyorlandi, shuning uchun real script compilation va Console xatolari tekshirilmadi. Yuqoridagi "tayyor" bandi — qo'lda o'qib chiqilgan statik tekshiruv, Unity'ning o'zi bergan compile natijasi emas. Buni tasdiqlash uchun QADAM 2 bo'yicha loyihani haqiqiy Unity Editor'da oching.
- `Level01_Test.unity` sahnasi — atayin qo'shilmagan (qo'lda YAML yozish GUID xatosi xavfini oshiradi). Pastdagi qadamlar bo'yicha Editor'da yarating.
- `ProjectSettings/ProjectSettings.asset` (Bundle ID, Player sozlamalari fayl sifatida) — hali yo'q. Unity birinchi ochilishda standart qiymatlar bilan yaratadi, keyin 9-bo'limdagi qiymatlarni qo'lda kiritish kerak.
- GameManager'dagi 4 ta manager fieldini (Audio/Save/Settings/Localization) Inspector'da bog'lash — hali bajarilmagan, 5-bo'limga qarang.

---

## LOYIHANI OCHISH

Bu ZIP endi tayyor loyiha (`Assets/`, `Packages/manifest.json`, `ProjectSettings/ProjectVersion.txt`) — skriptlar allaqachon to'g'ri joyda. Kerakli versiya: **Unity 2022.3 LTS** (2022.3.x). Android build uchun modul: **Android Build Support** (+ SDK/NDK Tools + OpenJDK) — Unity Hub'da Editor o'rnatishda belgilang. Ochish yo'llari uchun `PHASE_01_GUIDE.md` QADAM 2'ga qarang.

---

## SKRIPTLAR QAYERDA (v1.1 — tayyor joylashtirilgan)

| Fayl | Joylashuv | Namespace |
|------|-----------|-----------|
| GameManager.cs | Assets/Game/Core/ | Sohibqiron.Core |
| PlayerController.cs | Assets/Game/Characters/Player/ | Sohibqiron.Characters.Player |
| PlayerAnimationController.cs | Assets/Game/Characters/Player/ | Sohibqiron.Characters.Player |
| CameraManager.cs | Assets/Game/Camera/ | Sohibqiron.CameraSystem *(v1.1'da qayta nomlandi)* |
| InputManager.cs | Assets/Game/Input/ | Sohibqiron.InputSystem *(v1.1'da qayta nomlandi)* |
| GraphicsSettingsManager.cs | Assets/Game/Settings/ | Sohibqiron.Settings |
| SaveSystem.cs | Assets/Game/SaveSystem/ | Sohibqiron.SaveSystem |
| AudioManager.cs | Assets/Game/Audio/ | Sohibqiron.Audio |
| LocalizationManager.cs | Assets/Game/Localization/ | Sohibqiron.Localization |
| HistoricalDatabase.cs | Assets/Game/HistoricalData/ | Sohibqiron.HistoricalData |
| PerformanceMonitor.cs | Assets/Game/Tools/ | Sohibqiron.Tools |

**Eslatma:** `CameraManager` va `InputManager` namespace'lari `Sohibqiron.Camera` / `Sohibqiron.Input` edi — bular `UnityEngine.Camera` va `UnityEngine.Input` bilan to'qnashish xavfi bor edi, shuning uchun `Sohibqiron.CameraSystem` / `Sohibqiron.InputSystem`'ga o'zgartirildi. Agar Inspector'da eski skript nomini qidirsangiz, klass nomlari (`CameraManager`, `InputManager`) o'zgarmagan — faqat namespace o'zgargan.

**v1.2 tekshiruv izohi:** `SaveSystem.cs` fayli o'ziga xos — klass nomi (`SaveSystem`) o'z namespace'ining oxirgi bo'lagi (`Sohibqiron.SaveSystem`) bilan bir xil. Bu qonuniy C# va compile xatosiga olib kelmaydi (klass to'g'ridan-to'g'ri o'z namespace'ining a'zosi sifatida topiladi), lekin ba'zi tahlil vositalari buni style ogohlantirishi sifatida belgilashi mumkin. Hozircha o'zgartirish shart emas.

---

## TEST SAHNASINI YARATISH

Bu qadam ZIP ichida YO'Q (sabab: `PHASE_01_GUIDE.md` QADAM 6'ga qarang) — quyidagilarni Unity Editor'da qo'lda bajaring.

### 1. Yangi sahna yarating
File → New Scene → Basic (Built-in) → Create

Saqlang: `Assets/Game/Scenes/Level01_Test.unity`

---

### 2. Sinov erlik (floor)
Hierarchy → RMB → 3D Object → Plane (yoki Terrain, agar terrain tizimi bilan ishlashni xohlasangiz)
- Scale: (10, 1, 10) — taxminan 100x100 birlik maydon
- Position: (0, 0, 0)
- Layer: yangi "Ground" nomli layer yarating va shuni tanlang

---

### 3. Asosiy yorug'lik
Hierarchy ichida Directional Light borligini tekshiring.
- Color: issiq (RGB: 255, 235, 200)
- Intensity: 1.2
- Rotation: (50, -30, 0)

---

### 4. Player yaratish

**A. Capsule yarating** (vaqtincha model):
Hierarchy → RMB → 3D Object → Capsule
- Position: (0, 1, 0)
- Name: "Player"

**B. Skriptlar qo'shing:**
Player obyektini tanlang → Inspector → Add Component:
- `PlayerController`
- `PlayerAnimationController`
- CharacterController (avtomatik qo'shiladi)

**C. Animator o'rnating:**
- PlayerAnimationController skriptida Animator kerak
- Vaqtincha: Animator komponentini qo'shing, Controller bo'sh qolishi mumkin

**D. Layer sozlash:**
- PlayerController → Ground Layer maydonida "Ground" ni belgilang (2-qadamda yaratilgan layer)

---

### 5. Managers yarating

Hierarchy → RMB → Create Empty → "GameManagers" deb nomlang.

Bu obyektga qo'shing:
- `GameManager`
- `InputManager`
- `GraphicsSettingsManager`
- `AudioManager`
- `LocalizationManager`
- `SaveSystem`
- `PerformanceMonitor`

**GameManager Inspector'da** — 4 ta manager fieldini bog'lang: Audio Manager, Save System, Settings Manager (bu endi `GraphicsSettingsManager` tipida), Localization Manager — barchasini shu "GameManagers" obyektidan sudrab tashlang.

AudioManager'da AudioSource komponentlari kerak:
- 4 ta yordamchi AudioSource yarating yoki GameManagers ga 4 ta AudioSource qo'shing (Music, Ambient, SFX, Voice)

---

### 6. Kamera sozlash

Main Camera ni tanlang:
- `CameraManager` skriptini qo'shing
- Target: Player obyektini sudrab tashlang
- Collision Layers: "Default" belgilang

---

### 7. (Ixtiyoriy) EventSystem

Agar keyinchalik UI/HUD qo'shsangiz: Hierarchy → RMB → UI → Event System. Phase 01 test sahnasi uchun shart emas — `InputManager` UI ustidan bosishni tekshiradi, lekin EventSystem bo'lmasa ham xatosiz ishlaydi (shunchaki UI ustida ekanini tekshirmaydi).

---

### 8. Yorug'lik va Skybox

Window → Rendering → Lighting:
- Skybox: standart Unity skybox
- Ambient Mode: Skybox

---

### 9. Android uchun

File → Build Settings:
- Platform: Android
- Switch Platform (birinchi marta uzoq kutadi — normal)

Edit → Project Settings → Player:
- Bundle Identifier: `com.sohibqiron.riseoftimur`
- Android → Scripting Backend: IL2CPP
- Android → Target Architecture: ARM64 belgilang

---

## SINOV

O'yin bosilganda:

**Kompyuterda:**
- WASD = harakat
- Sichqoncha = kamera (o'ng tugma ushlab)
- Space = sakrash
- Shift = yugurish
- Ctrl = dodge
- F1 = FPS monitor

**Ishlashi kerak:**
- Capsule harakati
- Kamera personaj orqasida
- FPS panel yuqori chap burchakda
- Konsol da xato yo'q

---

## KEYINGI QADAM (Phase 02)

Phase 01 ishlasa:
1. ✅ Harakat ishlaydi
2. ✅ Kamera ishlaydi
3. ✅ FPS 30+ ga tushadi
4. ✅ Android build chiqarish mumkin
5. ✅ Konsol da kritik xato yo'q

Keyin Phase 02: Ot tizimi, Kamon jang, Samarqand muhiti.

---

## YORDAM

Agar xato chiqsa:

1. Konsol (Window → General → Console) ni oching
2. Qizil xatolarni menga yuboring
3. Skript nomi va xato matni

Har bir xatoni birgalikda hal qilamiz.
