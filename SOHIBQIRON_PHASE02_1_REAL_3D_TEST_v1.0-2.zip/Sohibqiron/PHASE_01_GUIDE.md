# SOHIBQIRON — PHASE 01: Unity Foundation Guide
## Noldan Professional 3D O'yingacha
### v1.2 — tekshirilgan va yakunlangan loyiha skeleti

---

## v1.2'DA NIMA O'ZGARDI (FINALIZATION PASS)

- Barcha 11 ta `.cs` fayl qo'lda, qator-baqator o'qib chiqildi: namespace, `using` direktivalari, klass nomlari, metod/event/tur (type) mosligi tekshirildi — **hech qanday nomuvofiqlik topilmadi, ishlayotgan kodga hech narsa o'zgartirilmadi**.
- Butun loyiha bo'ylab qidiruv o'tkazildi: eski `Assets/_Project/` yo'llari, eski `Sohibqiron.Input` / `Sohibqiron.Camera` namespace'lari, yalang'och (noto'g'ri) `SettingsManager` turi, probelli bundle ID — **hech biri topilmadi**, hammasi v1.1'dagidek toza.
- Papka strukturasi tekshirildi — barcha skriptlar allaqachon to'g'ri `Assets/Game/...` papkalarida edi, hech narsani ko'chirish shart bo'lmadi.
- `Packages/manifest.json` va `ProjectSettings/ProjectVersion.txt` qayta ko'rib chiqildi — mavjud va mazmuni Phase 01 skriptlariga mos, o'zgartirilmadi.
- Test sahnasi (`Level01_Test.unity`) hamon atayin yaratilmadi, Phase 02 ham boshlanmadi — so'ralganidek faqat Phase 01 yakunlandi.
- **Muhim chegara:** bu tekshiruv qo'lda, statik o'qish orqali bajarildi. Ushbu muhitda Unity Editor yo'q — shuning uchun haqiqiy compile tekshiruvi (script compilation, Console xatolari) **bajarilmadi**. Batafsil uchun `SETUP_INSTRUCTIONS.md`dagi "Hozir nima tayyor / nima emas" bo'limiga qarang.

---

## v1.1'DA NIMA O'ZGARDI

- `GameManager.cs` kompilyatsiya xatosi tuzatildi (noto'g'ri `SettingsManager` turi va yetishmayotgan `using` direktivalari).
- Xavfli namespace'lar qayta nomlandi: `Sohibqiron.Input` → `Sohibqiron.InputSystem`, `Sohibqiron.Camera` → `Sohibqiron.CameraSystem`.
- Android bundle identifier tuzatildi: `com.sohibqiron.riseoftimur` (probelsiz).
- Endi bu ZIP alohida skriptlar emas, balki **tayyor Unity loyiha skeleti** (`Assets/`, `Packages/manifest.json`, `ProjectSettings/ProjectVersion.txt`).
- Barcha skript joylashuvlari `Assets/Game/...` konvensiyasiga o'tkazildi (Master Prompt Section 20'ga mos).

---

## QADAM 1: Unity O'rnatish

### 1.1 Unity Hub yuklab olish
1. https://unity.com/download — saytga kiring
2. **Unity Hub** yuklab oling (bepul)
3. O'rnating va ishga tushiring

### 1.2 Unity versiyasi
Unity Hub ichida:
- **Installs** → **Install Editor**
- Versiya: **Unity 2022.3 LTS** (eng barqaror, Android uchun ideal — istalgan 2022.3.x patch versiyasi ishlaydi)
- "LTS" — Long Term Support, professional loyihalar uchun

### 1.3 Modullar (o'rnatishda belgilang)
- ✅ **Android Build Support**
- ✅ **Android SDK & NDK Tools**
- ✅ **OpenJDK**

---

## QADAM 2: Loyihani Ochish (IKKITA YO'L)

Bu ZIP endi tayyor loyiha skeleti (`Sohibqiron/` papkasi ichida `Assets/`, `Packages/`, `ProjectSettings/`). U real Unity'da HECH QACHON ochilmagan/tekshirilmagan — quyida ikkala variant ham xavfsiz:

### A) TO'G'RIDAN-TO'G'RI OCHISH (tavsiya etiladi)
1. Unity Hub → **Add** → **Add project from disk**
2. ZIP'dan chiqarilgan `Sohibqiron/` papkasini tanlang
3. Ochganda Unity versiya mos kelmasa — "Change Editor Version" oynasida sizdagi 2022.3.x'ni tanlang
4. Unity birinchi ochilishda yetishmagan `ProjectSettings/*.asset` fayllarni (GraphicsSettings, TagManager va h.k.) standart qiymatlar bilan o'zi yaratadi — bu normal Unity xatti-harakati

### B) XAVFSIZ ZAXIRA YO'L (agar A muammo bersa)
1. Unity Hub → **New Project** → Template: **3D (Core)** → nomi `Sohibqiron`
2. Yangi loyiha yaratilgach, uning `Assets/` papkasini ushbu ZIP'dagi `Assets/Game/` papkasiga almashtiring (yoki ichiga ko'chiring)
3. `Packages/manifest.json`'ni solishtiring — yangi loyihaniki to'liqroq bo'ladi, uni saqlab qoling

---

## QADAM 3: Papka Strukturasi (v1.1 — Assets/Game/)

```
Assets/
└── Game/
    ├── Core/                      (GameManager.cs)
    ├── Characters/
    │   └── Player/                (PlayerController.cs, PlayerAnimationController.cs)
    ├── Camera/                    (CameraManager.cs)
    ├── Input/                     (InputManager.cs)
    ├── Settings/                  (GraphicsSettingsManager.cs)
    ├── Audio/                     (AudioManager.cs)
    ├── SaveSystem/                (SaveSystem.cs)
    ├── Localization/              (LocalizationManager.cs)
    ├── HistoricalData/            (HistoricalDatabase.cs)
    ├── Tools/                     (PerformanceMonitor.cs)
    └── Scenes/                    (bu yerga Level01_Test.unity yarating — QADAM 6)
```

Keyingi fazalarda (Horse/, Combat/, EnemyAI/, World/, Missions/ va h.k.) shu `Assets/Game/` ichiga qo'shiladi — Master Prompt Section 20'dagi to'liq struktura shu yerga kengayadi.

---

## QADAM 4: Android Sozlamalari

**Edit → Project Settings → Player**:

- Company Name: `SohibqironStudios`
- Product Name: `Sohibqiron`
- Bundle Identifier: `com.sohibqiron.riseoftimur`

**Platform: Android**:
- File → Build Settings → Android → Switch Platform
- Minimum API Level: **Android 7.0 (API 24)**
- Target API Level: **Android 13 (API 33)**
- Scripting Backend: **IL2CPP**
- Target Architecture: **ARM64**

---

## QADAM 5: Skriptlar

Skriptlar allaqachon to'g'ri papkalarga joylashtirilgan (QADAM 3'ga qarang). Qo'shimcha ish shart emas.

---

## QADAM 6: Test Sahnasini Yaratish

Batafsil qadamlar uchun `SETUP_INSTRUCTIONS.md` fayliga qarang — u yerda `Assets/Game/Scenes/Level01_Test.unity` sahnasini qo'lda yaratish bo'yicha aniq ko'rsatmalar bor (Terrain/floor, Player capsule, GameManagers, kamera, va h.k.).

**MUHIM:** Sahna fayli (`.unity`) ushbu ZIP'ga QO'SHILMAGAN. Sababi: bu murakkab YAML formatidagi fayl, va uni haqiqiy Unity Editor'da ochib tekshirmasdan qo'lda yozish xato ehtimolini oshiradi (masalan, MonoBehaviour GUID moslik xatosi Unity Editor'da ochilgunga qadar sezilmay qolishi mumkin). Sizning "QUALITY > SPEED" qoidangizga ko'ra, buni Unity'ning o'zida 5-10 daqiqada, 100% ishonchli tarzda yaratish — noaniq qo'lda yozilgan faylni keyinroq tuzatishga urinishdan ancha yaxshiroq.
